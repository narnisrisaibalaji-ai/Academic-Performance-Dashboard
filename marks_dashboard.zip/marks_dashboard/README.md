# Academic Performance Dashboard

Streamlit app for entering class marks, validating them, and seeing subject-wise performance.

## Run
    pip install -r requirements.txt
    streamlit run app.py

## Demo path
1. Sidebar: **Load sample data** (44 entries incl. boundary cases 0, 39.5, 40, 100).
2. **Add marks**: try marks `abc`, or `120` out of `100`; each problem is reported.
3. **Overview**: grade band, charts, subject table, warnings. **Records**: search and filter.
4. **Import and export**: import `data/legacy_import_with_errors.csv` to see the row-by-row error log; download Markdown, text and CSV reports.
5. Stop the app, run it again: records persist in `data/records.json`.

## Files
- `core.py`: validation, JSON persistence, analytics, charts, import/export (no UI code)
- `app.py`: Streamlit interface
- `gen_sample.py`: rebuilds the sample CSV/JSON
