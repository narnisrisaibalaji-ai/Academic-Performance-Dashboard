"""Academic Performance Dashboard: Streamlit interface.  Run: streamlit run app.py"""
import io
from datetime import date

import matplotlib.pyplot as plt
import pandas as pd
import streamlit as st

import core

st.set_page_config(page_title="Class Marks Dashboard", page_icon="📊", layout="wide")
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Schibsted+Grotesk:wght@400;600;800&display=swap');
html, body, [class*="css"], .stMarkdown { font-family: 'Schibsted Grotesk', sans-serif; }
h1 { font-weight: 800; letter-spacing: -.02em; }
.band { display:flex; height:46px; border-radius:6px; overflow:hidden; margin:.25rem 0 1.25rem; }
.band div { display:flex; align-items:center; padding-left:10px; color:#fff; font-weight:600; font-size:.9rem; white-space:nowrap; overflow:hidden; }
.warn { border-left:4px solid #D9A21B; padding:.35rem .75rem; margin:.25rem 0; background:#E6EEEF; border-radius:0 4px 4px 0; }
.warn.fail { border-color:#B3261E; }
</style>""", unsafe_allow_html=True)

if "records" not in st.session_state:
    st.session_state.records = core.load()
records = st.session_state.records


def commit():
    core.save(st.session_state.records)


def png(fig) -> bytes:
    buf = io.BytesIO(); fig.savefig(buf, format="png", dpi=150); return buf.getvalue()


def show(fig):
    st.pyplot(fig); plt.close(fig)


# ---------- sidebar ----------
with st.sidebar:
    st.header("Class marks")
    st.caption(f"{len(records)} entries saved to data/records.json")
    if st.button("Load sample data", width="stretch", disabled=bool(records)):
        good, _ = core.import_csv(open(core.DATA_DIR / "sample_marks.csv", encoding="utf-8").read(), records)
        records.extend(good); commit(); st.rerun()
    if records and st.button("Clear all records", width="stretch"):
        records.clear(); commit(); st.rerun()

st.title("Academic Performance Dashboard")
tab_over, tab_add, tab_rec, tab_io = st.tabs(["Overview", "Add marks", "Records", "Import and export"])

# ---------- overview ----------
with tab_over:
    s = core.summary(records)
    if not s:
        st.info("No marks yet. Add an entry, import a CSV, or load the sample data from the sidebar.")
    else:
        c = st.columns(4)
        c[0].metric("Class average", f"{s['average']}%")
        c[1].metric("Pass rate", f"{s['pass_rate']}%")
        c[2].metric("Strongest subject", s["best_subject"])
        c[3].metric("Weakest subject", s["weakest_subject"])

        st.subheader("How the class is grading")
        st.markdown('<div class="band">' + "".join(
            f'<div style="flex:{n};background:{core.GRADE_COLORS[g]}">{g} · {n}</div>'
            for g, n in s["grades"].items() if n) + "</div>", unsafe_allow_html=True)

        left, right = st.columns(2)
        with left: show(core.subject_chart(records))
        with right: show(core.distribution_chart(records))

        subject = st.selectbox("Trend for", ["All subjects"] + list(s["by_subject"]))
        trend = core.trend_chart(records, None if subject == "All subjects" else subject)
        show(trend)
        st.download_button("Download trend chart (PNG)", png(trend), "trend.png", "image/png")

        a, b = st.columns(2)
        with a:
            st.subheader("By subject")
            st.dataframe(pd.DataFrame(s["by_subject"]).T.rename(columns={"n": "Entries", "avg": "Average %", "high": "High", "low": "Low", "pass_rate": "Pass rate %"}), width="stretch")
        with b:
            st.subheader("Student ranking")
            st.dataframe(pd.DataFrame(s["by_student"]).rename(columns={"student_id": "ID", "name": "Name", "avg": "Average %"})[["ID", "Name", "Average %", "low", "high"]],
                         hide_index=True, width="stretch")

        warns = core.warnings(records)
        with st.expander(f"Warnings ({len(warns)})", expanded=bool(warns)):
            for w in warns:
                st.markdown(f'<div class="warn {"fail" if w.startswith(("FAIL", "DROP")) else ""}">{w}</div>', unsafe_allow_html=True)

# ---------- add ----------
with tab_add:
    with st.form("add", clear_on_submit=False):
        a, b, c = st.columns(3)
        sid = a.text_input("Student ID", placeholder="S109")
        name = b.text_input("Student name")
        cls = c.text_input("Class", placeholder="10A")
        a, b, c = st.columns(3)
        sub = a.text_input("Subject", placeholder="Mathematics")
        asm = b.text_input("Assessment", placeholder="Midterm")
        when = c.date_input("Date", value=date.today(), max_value=date.today())
        a, b = st.columns(2)
        marks = a.text_input("Marks obtained", placeholder="72")
        top = b.text_input("Maximum marks", value="100")
        if st.form_submit_button("Save entry", type="primary"):
            try:
                rec = core.validate(dict(student_id=sid, name=name, class_name=cls, subject=sub, assessment=asm,
                                         marks=marks, max_marks=top, date=when.isoformat()))
                if any(r.key == rec.key for r in records):
                    st.error(f"{rec.name} already has a {rec.subject} / {rec.assessment} entry. Delete it first to replace it.")
                else:
                    records.append(rec); commit()
                    st.success(f"Saved {rec.name}: {rec.subject} {rec.marks:g}/{rec.max_marks:g} ({rec.percent}%, grade {rec.grade}).")
            except core.ValidationError as e:
                for p in e.problems:
                    st.error(p)

# ---------- records ----------
with tab_rec:
    f = st.columns([2, 1, 1, 1])
    kw = f[0].text_input("Search", placeholder="Name, ID, subject or assessment")
    cls_f = f[1].selectbox("Class", [""] + sorted({r.class_name for r in records}), format_func=lambda x: x or "All")
    sub_f = f[2].selectbox("Subject", [""] + sorted({r.subject for r in records}), format_func=lambda x: x or "All")
    st_f = f[3].selectbox("Status", ["", "OK", "Watch", "Fail"], format_func=lambda x: x or "All")
    hits = core.search(records, kw, cls_f, sub_f, st_f)
    st.caption(f"{len(hits)} of {len(records)} entries")
    if hits:
        df = pd.DataFrame([r.to_row() for r in hits])
        st.dataframe(df.style.map(lambda v: {"Fail": "color:#B3261E;font-weight:600", "Watch": "color:#A87900;font-weight:600"}.get(v, ""), subset=["status"]),
                     hide_index=True, width="stretch", height=380)
        pick = st.selectbox("Delete an entry", [None] + hits, format_func=lambda r: "Choose entry" if r is None else f"{r.student_id} · {r.subject} · {r.assessment}")
        if pick is not None and st.button("Delete entry"):
            records.remove(pick); commit(); st.rerun()

# ---------- import / export ----------
with tab_io:
    up = st.file_uploader("Import marks from CSV", type="csv", help="Columns: " + ", ".join(core.FIELDS))
    if up is not None and st.button("Import file", type="primary"):
        try:
            good, errs = core.import_csv(up.getvalue().decode("utf-8-sig"), records)
        except UnicodeDecodeError:
            good, errs = [], [(1, "File is not valid UTF-8 text.")]
        records.extend(good)
        if good: commit()
        st.success(f"Imported {len(good)} rows.") if good else st.warning("No rows imported.")
        if errs:
            st.error(f"{len(errs)} rows skipped")
            st.dataframe(pd.DataFrame(errs, columns=["CSV row", "Problem"]), hide_index=True, width="stretch")
    st.divider()
    st.subheader("Export report")
    c = st.columns(3)
    c[0].download_button("Markdown report", core.to_markdown(records), "report.md", width="stretch")
    c[1].download_button("Plain-text audit log", core.to_text(records), "audit.txt", width="stretch")
    c[2].download_button("CSV with grades", core.to_csv(records), "marks_with_grades.csv", width="stretch")
