"""Academic Performance Dashboard: core logic (no UI code)."""
from __future__ import annotations

import csv
import io
import json
import math
import os
import re
import statistics
from dataclasses import dataclass
from datetime import date
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

DATA_DIR = Path(__file__).parent / "data"
DB_FILE = DATA_DIR / "records.json"
FIELDS = ["student_id", "name", "class_name", "subject", "assessment", "marks", "max_marks", "date"]
PASS_MARK, WATCH_MARK = 40.0, 50.0
GRADES = [(80, "A"), (70, "B"), (60, "C"), (50, "D"), (40, "E"), (0, "F")]
GRADE_COLORS = {"A": "#0F6B6F", "B": "#3F8F8A", "C": "#8DB5A0", "D": "#D9A21B", "E": "#D9783B", "F": "#B3261E"}

ID_RE = re.compile(r"^[A-Za-z0-9_-]{2,12}$")
NAME_RE = re.compile(r"^[A-Za-z][A-Za-z .'-]{1,59}$")
LABEL_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 &/.+-]{0,39}$")


class ValidationError(ValueError):
    def __init__(self, problems):
        self.problems = list(problems)
        super().__init__("; ".join(self.problems))


@dataclass
class Record:
    student_id: str
    name: str
    class_name: str
    subject: str
    assessment: str
    marks: float
    max_marks: float
    date: str

    @property
    def percent(self) -> float:
        return round(self.marks / self.max_marks * 100, 1)

    @property
    def grade(self) -> str:
        return next(g for cut, g in GRADES if self.percent >= cut)

    @property
    def status(self) -> str:
        return "Fail" if self.percent < PASS_MARK else "Watch" if self.percent < WATCH_MARK else "OK"

    @property
    def key(self) -> tuple:
        return (self.student_id.lower(), self.subject.lower(), self.assessment.lower())

    def to_dict(self) -> dict:
        return {f: getattr(self, f) for f in FIELDS}

    def to_row(self) -> dict:
        return {**self.to_dict(), "percent": self.percent, "grade": self.grade, "status": self.status}


# ---------- validation ----------
def _number(value, label, problems):
    text = str(value if value is not None else "").strip()
    if not text:
        problems.append(f"{label} is required.")
        return None
    try:
        x = float(text)
    except ValueError:
        problems.append(f"{label} must be a number (got '{text}').")
        return None
    if not math.isfinite(x):
        problems.append(f"{label} must be a finite number.")
        return None
    return x


def validate(raw: dict) -> Record:
    """Sanitise one raw row. Raises ValidationError listing every problem found."""
    p = []
    g = lambda k: str(raw.get(k) or "").strip()
    sid, name, cls, sub, asm = g("student_id"), g("name"), g("class_name"), g("subject"), g("assessment")
    if not ID_RE.match(sid):
        p.append("Student ID must be 2-12 letters, digits, '-' or '_'.")
    if not NAME_RE.match(name):
        p.append("Name must start with a letter and use only letters, spaces, . ' -")
    for label, val in (("Class", cls), ("Subject", sub), ("Assessment", asm)):
        if not LABEL_RE.match(val):
            p.append(f"{label} is required (max 40 characters, no special symbols).")
    marks = _number(raw.get("marks"), "Marks", p)
    top = _number(raw.get("max_marks"), "Maximum marks", p)
    top_ok = top is not None and 0 < top <= 1000
    if top is not None and not top_ok:
        p.append("Maximum marks must be above 0 and at most 1000.")
    if marks is not None and top_ok and not 0 <= marks <= top:
        p.append(f"Marks must be between 0 and {top:g}.")
    d = g("date")
    try:
        if date.fromisoformat(d) > date.today():
            p.append("Date cannot be in the future.")
    except ValueError:
        p.append("Date must use the format YYYY-MM-DD.")
    if p:
        raise ValidationError(p)
    return Record(sid.upper(), " ".join(name.split()).title(), cls.upper(), sub.title(), asm.title(),
                  round(marks, 2), round(top, 2), d)


# ---------- persistence ----------
def save(records, path: Path = DB_FILE) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps([r.to_dict() for r in records], indent=2), encoding="utf-8")
    os.replace(tmp, path)  # atomic: never leaves a half-written file


def load(path: Path = DB_FILE) -> list[Record]:
    """Load records; create a clean file if missing, quarantine it if corrupted."""
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(raw, list):
            raise ValueError("expected a JSON list")
    except FileNotFoundError:
        save([], path)
        return []
    except (json.JSONDecodeError, ValueError, OSError):
        try:
            path.replace(path.with_suffix(".corrupt.bak"))
        except OSError:
            pass
        save([], path)
        return []
    out = []
    for row in raw:
        try:
            out.append(validate(row))
        except (ValidationError, AttributeError):
            continue
    return out


# ---------- search ----------
def search(records, keyword="", class_name=None, subject=None, status=None):
    kw = keyword.strip().lower()
    return [r for r in records
            if (not kw or kw in f"{r.student_id} {r.name} {r.subject} {r.assessment} {r.class_name}".lower())
            and (not class_name or r.class_name == class_name)
            and (not subject or r.subject == subject)
            and (not status or r.status == status)]


# ---------- analytics ----------
def _stats(pcts):
    return {"n": len(pcts), "avg": round(statistics.mean(pcts), 1), "high": max(pcts), "low": min(pcts),
            "pass_rate": round(100 * sum(x >= PASS_MARK for x in pcts) / len(pcts), 1)}


def grade_counts(records) -> dict:
    counts = {g: 0 for _, g in GRADES}
    for r in records:
        counts[r.grade] += 1
    return counts


def summary(records):
    if not records:
        return None
    pcts = [r.percent for r in records]
    by_subject = {s: _stats([r.percent for r in records if r.subject == s]) for s in sorted({r.subject for r in records})}
    ids = {r.student_id: r.name for r in records}
    by_student = sorted(({"student_id": i, "name": n, **_stats([r.percent for r in records if r.student_id == i])}
                         for i, n in ids.items()), key=lambda s: -s["avg"])
    return {"entries": len(records), "students": len(ids), "average": round(statistics.mean(pcts), 1),
            "median": round(statistics.median(pcts), 1), "pass_rate": round(100 * sum(x >= PASS_MARK for x in pcts) / len(pcts), 1),
            "best_subject": max(by_subject, key=lambda s: by_subject[s]["avg"]),
            "weakest_subject": min(by_subject, key=lambda s: by_subject[s]["avg"]),
            "by_subject": by_subject, "by_student": by_student, "grades": grade_counts(records)}


def warnings(records) -> list[str]:
    out, seen = [], {}
    for r in records:
        if r.status == "Fail":
            out.append(f"FAIL: {r.name} scored {r.percent}% in {r.subject} ({r.assessment}).")
        elif r.status == "Watch":
            out.append(f"WATCH: {r.name} is close to the pass line in {r.subject} at {r.percent}% ({r.assessment}).")
        if r.marks == 0:
            out.append(f"CHECK: {r.name} has 0 marks in {r.subject} ({r.assessment}); confirm this is not a missing entry.")
        if r.key in seen:
            out.append(f"DUPLICATE: {r.name} already has a {r.subject} / {r.assessment} entry.")
        seen[r.key] = r
    series = {}
    for r in sorted(records, key=lambda r: r.date):
        series.setdefault((r.student_id, r.subject), []).append(r)
    for rows in series.values():
        if len(rows) > 1 and rows[-2].percent - rows[-1].percent >= 20:
            out.append(f"DROP: {rows[-1].name} fell {rows[-2].percent - rows[-1].percent:.0f} points in {rows[-1].subject} since the last assessment.")
    return out


# ---------- charts ----------
def _fig(title):
    fig, ax = plt.subplots(figsize=(6, 3.6))
    fig.patch.set_facecolor("#F5F7F7"); ax.set_facecolor("#F5F7F7")
    ax.set_title(title, loc="left", fontsize=11, fontweight="bold", color="#14282E")
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.grid(axis="y", alpha=.25)
    return fig, ax


def subject_chart(records):
    fig, ax = _fig("Average score by subject (%)")
    s = summary(records)
    if s:
        names = list(s["by_subject"]); vals = [s["by_subject"][n]["avg"] for n in names]
        bars = ax.bar(names, vals, color=["#B3261E" if v < PASS_MARK else "#D9A21B" if v < WATCH_MARK else "#0F6B6F" for v in vals])
        ax.bar_label(bars, fmt="%.1f", fontsize=8); ax.set_ylim(0, 100)
        ax.axhline(PASS_MARK, color="#B3261E", ls="--", lw=1)
        plt.setp(ax.get_xticklabels(), rotation=20, ha="right", fontsize=8)
    fig.tight_layout()
    return fig


def distribution_chart(records):
    fig, ax = _fig("Score distribution")
    if records:
        ax.hist([r.percent for r in records], bins=range(0, 101, 10), color="#3F8F8A", edgecolor="#F5F7F7")
        ax.axvline(PASS_MARK, color="#B3261E", ls="--", lw=1)
        ax.set_xlabel("Percent"); ax.set_ylabel("Entries")
    fig.tight_layout()
    return fig


def trend_chart(records, subject=None):
    fig, ax = _fig(f"Class average over time{' - ' + subject if subject else ''} (%)")
    rows = [r for r in records if not subject or r.subject == subject]
    by_date = {}
    for r in rows:
        by_date.setdefault(r.date, []).append(r.percent)
    if by_date:
        ds = sorted(by_date)
        ax.plot(ds, [statistics.mean(by_date[d]) for d in ds], marker="o", color="#0F6B6F", lw=2)
        ax.set_ylim(0, 100); ax.axhline(PASS_MARK, color="#B3261E", ls="--", lw=1)
        plt.setp(ax.get_xticklabels(), rotation=30, ha="right", fontsize=8)
    fig.tight_layout()
    return fig


# ---------- import / export ----------
def import_csv(text: str, existing):
    """Row-by-row import. Returns (valid_records, [(row_number, message), ...])."""
    good, errors = [], []
    seen = {r.key for r in existing}
    reader = csv.DictReader(io.StringIO(text))
    missing = [f for f in FIELDS if f not in (reader.fieldnames or [])]
    if missing:
        return [], [(1, f"Missing column(s): {', '.join(missing)}")]
    for n, row in enumerate(reader, start=2):
        try:
            rec = validate(row)
            if rec.key in seen:
                raise ValidationError(["Duplicate of an existing student/subject/assessment entry."])
            seen.add(rec.key); good.append(rec)
        except ValidationError as e:
            errors.append((n, " ".join(e.problems)))
    return good, errors


def to_csv(records) -> str:
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=FIELDS + ["percent", "grade", "status"])
    w.writeheader(); w.writerows(r.to_row() for r in records)
    return buf.getvalue()


def to_markdown(records) -> str:
    s = summary(records)
    if not s:
        return "# Academic Performance Report\n\nNo records.\n"
    L = ["# Academic Performance Report", "", f"Generated {date.today()}", "",
         f"- Entries: {s['entries']} across {s['students']} students",
         f"- Average: {s['average']}% (median {s['median']}%), pass rate {s['pass_rate']}%",
         f"- Best subject: {s['best_subject']}; weakest: {s['weakest_subject']}", "",
         "## Subjects", "", "| Subject | Entries | Average | High | Low | Pass rate |", "|---|---|---|---|---|---|"]
    L += [f"| {k} | {v['n']} | {v['avg']} | {v['high']} | {v['low']} | {v['pass_rate']}% |" for k, v in s["by_subject"].items()]
    L += ["", "## Warnings", ""] + [f"- {w}" for w in warnings(records)[:50]]
    L += ["", "## Records", "", "| ID | Name | Class | Subject | Assessment | Marks | % | Grade |", "|---|---|---|---|---|---|---|---|"]
    L += [f"| {r.student_id} | {r.name} | {r.class_name} | {r.subject} | {r.assessment} | {r.marks:g}/{r.max_marks:g} | {r.percent} | {r.grade} |" for r in records]
    return "\n".join(L) + "\n"


def to_text(records) -> str:
    s = summary(records)
    if not s:
        return "ACADEMIC PERFORMANCE REPORT\nNo records.\n"
    L = ["ACADEMIC PERFORMANCE REPORT", f"Generated: {date.today()}", "-" * 60,
         f"Entries {s['entries']} | Students {s['students']} | Avg {s['average']}% | Pass rate {s['pass_rate']}%", "", "BY SUBJECT"]
    L += [f"  {k:<20}{v['avg']:>6}%  (n={v['n']}, pass {v['pass_rate']}%)" for k, v in s["by_subject"].items()]
    L += ["", "WARNINGS"] + [f"  {w}" for w in warnings(records)]
    return "\n".join(L) + "\n"
