"""Generates data/sample_marks.csv, sample_marks.json and legacy_import_with_errors.csv"""
import csv, json, random
from core import FIELDS, validate

random.seed(7)
students = [("S101","Aarav Mehta","10A",72),("S102","Diya Reddy","10A",85),("S103","Kabir Shah","10A",48),
            ("S104","Meera Nair","10B",91),("S105","Rohan Das","10B",60),("S106","Sana Khan","10B",36),
            ("S107","Vikram Rao","10A",67),("S108","Isha Verma","10B",78)]
subjects = [("Mathematics",100),("Science",100),("English",100),("History",100),("Computer Science",50)]
exams = [("Unit Test 1","2025-08-12"),("Midterm","2025-09-22"),("Unit Test 2","2025-10-27")]
rows = []
for i,(sid,name,cls,skill) in enumerate(students):
    for j,(sub,top) in enumerate(subjects):
        a,d = exams[(i+j)%3]
        pct = max(5, min(100, random.gauss(skill, 9)))
        rows.append(dict(student_id=sid,name=name,class_name=cls,subject=sub,assessment=a,
                         marks=round(pct/100*top*2)/2,max_marks=top,date=d))
# boundary / edge cases
rows += [dict(student_id="S103",name="Kabir Shah",class_name="10A",subject="Mathematics",assessment="Unit Test 2",marks=0,max_marks=100,date="2025-10-27"),
         dict(student_id="S104",name="Meera Nair",class_name="10B",subject="Science",assessment="Unit Test 2",marks=100,max_marks=100,date="2025-10-27"),
         dict(student_id="S105",name="Rohan Das",class_name="10B",subject="History",assessment="Unit Test 2",marks=40,max_marks=100,date="2025-10-27"),
         dict(student_id="S106",name="Sana Khan",class_name="10B",subject="English",assessment="Unit Test 2",marks=39.5,max_marks=100,date="2025-10-27")]
rows = [validate(r).to_dict() for r in rows]
with open("data/sample_marks.csv","w",newline="") as f:
    w = csv.DictWriter(f, fieldnames=FIELDS); w.writeheader(); w.writerows(rows)
json.dump(rows, open("data/sample_marks.json","w"), indent=2)
bad = [dict(student_id="S201",name="Neha Iyer",class_name="9A",subject="Science",assessment="Midterm",marks=64,max_marks=100,date="2025-09-22"),
       dict(student_id="S202",name="",class_name="9A",subject="Science",assessment="Midterm",marks=70,max_marks=100,date="2025-09-22"),
       dict(student_id="S203",name="Arjun Pillai",class_name="9A",subject="Maths",assessment="Midterm",marks="abc",max_marks=100,date="2025-09-22"),
       dict(student_id="S204",name="Tara Joshi",class_name="9B",subject="English",assessment="Midterm",marks=120,max_marks=100,date="2025-09-22"),
       dict(student_id="S205",name="Omar Sheikh",class_name="9B",subject="English",assessment="Midterm",marks=55,max_marks=100,date="22/09/2025"),
       dict(student_id="S101",name="Aarav Mehta",class_name="10A",subject="Mathematics",assessment="Unit Test 1",marks=70,max_marks=100,date="2025-08-12")]
with open("data/legacy_import_with_errors.csv","w",newline="") as f:
    w = csv.DictWriter(f, fieldnames=FIELDS); w.writeheader(); w.writerows(bad)
print(len(rows), "sample rows written")
